Dev3 - Week 1 Setup
1. Run `npm install` to install dependencies
2. Start dev server with `npm start`
3. Code only in your assigned files:
   src/pages/Approver/PendingApprovals.js
4. Do not modify common.css, Header.js, Footer.js, or Sidebar.js
