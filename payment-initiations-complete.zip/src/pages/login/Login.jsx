import React, { useState } from 'react';
import PrimaryButton from '../../common/components/PrimaryButton.jsx';
import FormInput from '../../common/components/FormInput.jsx';

export default function Login() {
  const [user, setUser] = useState('');
  const [pwd, setPwd] = useState('');
  const [attempts, setAttempts] = useState(0);
  const disabled = !user || !pwd || attempts >= 3;

  const submit = (e) => {
    e.preventDefault();
    setAttempts(a => a + 1);
  };

  return (
    <div className="card card-shadow p-4">
      <h2 className="h5 mb-3">Login</h2>
      {attempts > 0 && attempts < 3 && (
        <div className="alert alert-danger">Invalid credentials (mock). Attempts: {attempts}/3</div>
      )}
      {attempts >= 3 && (
        <div className="alert alert-warning">Account locked after 3 failed attempts (mock).</div>
      )}
      <form onSubmit={submit}>
        <FormInput label="Username" value={user} onChange={setUser} required />
        <FormInput label="Password" type="password" value={pwd} onChange={setPwd} required />
        <PrimaryButton disabled={disabled} type="submit">Sign in</PrimaryButton>
      </form>
    </div>
  );
}