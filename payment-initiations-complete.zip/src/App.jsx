import React from 'react';
import { Routes, Route, NavLink } from 'react-router-dom';
import Header from './common/components/Header.jsx';
import Footer from './common/components/Footer.jsx';
import Login from './pages/login/Login.jsx';
import PayrollPayment from './pages/payroll/PayrollPayment.jsx';
import ExcelInput from './pages/excel-input/ExcelInput.jsx';
import TransactionList from './pages/transaction-list/TransactionList.jsx';
import Approval from './pages/approval/Approval.jsx';
import AccountBalance from './pages/account-balance/AccountBalance.jsx';
import PrintPreview from './pages/print-preview/PrintPreview.jsx';

export default function App() {
  return (
    <div className="app d-flex flex-column min-vh-100">
      <Header />
      <div className="container-fluid py-3 flex-grow-1">
        <div className="row">
          <aside className="col-12 col-md-2 mb-3 mb-md-0">
            <nav className="list-group shadow-sm">
              {[
                ['Login','/'],
                ['Create PAY','/payroll'],
                ['Excel Input','/excel'],
                ['Transactions','/txns'],
                ['Approvals','/approvals'],
                ['Balances','/balances'],
                ['Print Preview','/print']
              ].map(([label, to]) => (
                <NavLink key={to} to={to} end className={({isActive}) =>
                  'list-group-item list-group-item-action' + (isActive?' active':'')
                }>{label}</NavLink>
              ))}
            </nav>
          </aside>
          <main className="col-12 col-md-10">
            <Routes>
              <Route path="/" element={<Login />} />
              <Route path="/payroll" element={<PayrollPayment />} />
              <Route path="/excel" element={<ExcelInput />} />
              <Route path="/txns" element={<TransactionList />} />
              <Route path="/approvals" element={<Approval />} />
              <Route path="/balances" element={<AccountBalance />} />
              <Route path="/print" element={<PrintPreview />} />
            </Routes>
          </main>
        </div>
      </div>
      <Footer />
    </div>
  );
}
