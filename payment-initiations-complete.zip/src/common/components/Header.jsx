import React from 'react';

export default function Header() {
  return (
    <header className="brand-gradient py-2 px-3">
      <div className="d-flex align-items-center justify-content-between container-fluid">
        <h1 className="h5 mb-0">Payment Initiations</h1>
        <div className="d-flex gap-3 small">
          <span>Help</span>
          <span>Profile</span>
        </div>
      </div>
    </header>
  );
}