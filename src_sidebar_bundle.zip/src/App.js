import React from 'react';
import { Routes, Route, Navigate, useLocation } from 'react-router-dom';
import Header from './common/components/Header';
import Footer from './common/components/Footer';
import Sidebar from './common/components/Sidebar';
import Login from './pages/login/Login';
import Dashboard from './pages/dashboard/Dashboard';
import PayrollPayment from './pages/payroll/PayrollPayment';
import ManagePayroll from './pages/manage-payroll/ManagePayroll';
import ApprovePayroll from './pages/approval/ApprovePayroll';
import TransactionList from './pages/transaction-list/TransactionList';
import AccountBalance from './pages/account-balance/AccountBalance';
import PrintPreview from './pages/print-preview/PrintPreview';

function RequireAuth({ children }) {
  const allowed = localStorage.getItem('allowedPages');
  return allowed ? children : <Navigate to="/login" replace />;
}

function Layout({ children }) {
  const location = useLocation();
  const pathToTitle = {
    '/dashboard': 'Dashboard',
    '/payroll': 'Payroll Payment',
    '/manage-payroll': 'Manage Payroll',
    '/approvals': 'Approve Payroll',
    '/txns': 'Transactions',
    '/balances': 'Account Balance',
    '/print': 'Print Preview'
  };
  const pageTitle = pathToTitle[location.pathname] || '';
  const currentUser = (localStorage.getItem('currentUser') || '').toUpperCase();

  return (
    <div className="app-shell">
      <Header title={pageTitle} currentUser={currentUser} />
      <div className="app-body">
        <Sidebar />
        <main className="app-main">
          {children}
        </main>
      </div>
      <Footer currentUser={currentUser} />
    </div>
  );
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route
        path="/*"
        element={
          <RequireAuth>
            <Layout>
              <Routes>
                <Route path="dashboard" element={<Dashboard />} />
                <Route path="payroll" element={<PayrollPayment />} />
                <Route path="manage-payroll" element={<ManagePayroll />} />
                <Route path="approvals" element={<ApprovePayroll />} />
                <Route path="txns" element={<TransactionList />} />
                <Route path="balances" element={<AccountBalance />} />
                <Route path="print" element={<PrintPreview />} />
                <Route path="*" element={<Navigate to="/dashboard" replace />} />
              </Routes>
            </Layout>
          </RequireAuth>
        }
      />
      <Route path="*" element={<Navigate to="/login" replace />} />
    </Routes>
  );
}
