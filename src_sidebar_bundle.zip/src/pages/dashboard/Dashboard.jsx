import React, { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { getAllBatches, subscribeToPayrollEvents } from '../../common/storage/payrollStore';

export default function Dashboard() {
  const navigate = useNavigate();
  const [batches, setBatches] = useState([]);
  const [notifications, setNotifications] = useState([]);

  const refresh = () => setBatches(getAllBatches());
  useEffect(() => {
    refresh();
    const unsub = subscribeToPayrollEvents(() => refresh());
    return () => unsub();
  }, []);

  // KPIs
  const kpis = useMemo(() => {
    const total = batches.length;
    const approved = batches.filter(b => b.status === 'Approved').length;
    const rejected = batches.filter(b => b.status === 'Rejected').length;
    const submitted = batches.filter(b => b.status === 'Submitted').length;
    const draft = batches.filter(b => b.status === 'Draft').length;
    const amount = batches.reduce((s,b)=> s + b.payments.reduce((x,p)=>x + Number(p.amount||0),0), 0);
    return { total, approved, rejected, submitted, draft, amount };
  }, [batches]);

  // Simple bar chart data (no external lib, using inline bars)
  const monthly = useMemo(() => {
    const map = {};
    batches.forEach(b => {
      const m = (b.instruction?.date || '').slice(0,7) || 'Unknown';
      const sum = b.payments.reduce((s,p)=> s + Number(p.amount || 0), 0);
      map[m] = (map[m] || 0) + sum;
    });
    return Object.entries(map).sort();
  }, [batches]);

  useEffect(() => {
    const unsub = subscribeToPayrollEvents((event)=>{
      const msg =
        event.type === 'statusChanged'
          ? `Batch #${event.batch.id} ${event.status}`
          : event.type === 'created'
          ? `Batch #${event.batch.id} created`
          : event.type === 'deleted'
          ? `Batch #${event.batchId} deleted`
          : 'Batch updated';
      setNotifications(prev => [{ id: Date.now(), msg, time: new Date().toLocaleTimeString() }, ...prev].slice(0,6));
    });
    return () => unsub();
  }, []);

  return (
    <div className="grid" style={{gap:20}}>
      {/* KPI Tiles */}
      <div className="grid cols-4">
        <div className="tile kpi"><div className="label">Total Batches</div><div className="num">{kpis.total}</div></div>
        <div className="tile kpi"><div className="label">Approved</div><div className="num">{kpis.approved}</div></div>
        <div className="tile kpi"><div className="label">Submitted</div><div className="num">{kpis.submitted}</div></div>
        <div className="tile kpi"><div className="label">Rejected</div><div className="num">{kpis.rejected}</div></div>
      </div>

      <div className="grid cols-4">
        {/* Mini chart */}
        <div className="tile" style={{gridColumn:'span 2'}}>
          <div className="kpi" style={{marginBottom:8}}>
            <div className="label">Payout Amount by Month</div>
            <div className="label">Total: {kpis.amount.toLocaleString()}</div>
          </div>
          <div style={{display:'flex', alignItems:'flex-end', gap:8, height:140}}>
            {monthly.map(([m, val]) => (
              <div key={m} title={`${m} : ${val}`} style={{flex:1}}>
                <div style={{height: Math.max(4, val/ (kpis.amount||1) * 120), background:'linear-gradient(180deg,#0072CE,#00A859)', borderRadius:6}} />
                <div style={{fontSize:12, textAlign:'center', marginTop:6}}>{m}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Links */}
        <div className="tile">
          <div className="kpi" style={{marginBottom:8}}><div className="label">Quick Actions</div></div>
          <div className="grid" style={{gridTemplateColumns:'repeat(2, minmax(0,1fr))', gap:10}}>
            <button className="btn btn-primary" onClick={()=>navigate('/payroll')}><i className="bi bi-cash-coin me-1"></i>Create Payroll</button>
            <button className="btn btn-primary" onClick={()=>navigate('/manage-payroll')}><i className="bi bi-list-check me-1"></i>Manage</button>
            <button className="btn btn-primary" onClick={()=>navigate('/approvals')}><i className="bi bi-shield-check me-1"></i>Approve</button>
            <button className="btn btn-primary" onClick={()=>navigate('/txns')}><i className="bi bi-clock-history me-1"></i>Transactions</button>
          </div>
        </div>

        {/* Notifications */}
        <div className="tile">
          <div className="kpi" style={{marginBottom:8}}><div className="label">Recent Activity</div></div>
          {notifications.length === 0 ? (
            <div className="label">No activity yet</div>
          ) : (
            <ul style={{listStyle:'none', padding:0, margin:0}}>
              {notifications.map(n => (
                <li key={n.id} style={{padding:'8px 0', borderBottom:'1px solid #e5e7eb'}}>
                  <div style={{fontWeight:600}}>{n.msg}</div>
                  <div style={{fontSize:12, color:'var(--muted)'}}>{n.time}</div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}
