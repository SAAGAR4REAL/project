import React, { useEffect, useState } from 'react';
import { accounts } from '../../common/mockData';
import { currencies } from '../../common/constants';
import BackToDashboard from '../../common/components/BackToDashboard';
import { useNavigate, useLocation } from 'react-router-dom';
import { getBatchById, upsertBatch } from '../../common/storage/payrollStore';

export default function PayrollPayment() {
  const navigate = useNavigate();
  const location = useLocation();
  const [editBatchId, setEditBatchId] = useState(null);
  const [instruction, setInstruction] = useState({ paymentCurrency:'', debitAccount:'', date:'' });
  const emptyRow = () => ({ payeeDetails:'', payeeName:'', accountNumber:'', reference:`REF-${Date.now()}`, amount:'' });
  const [payments, setPayments] = useState([emptyRow()]);

  useEffect(() => {
    if (location.state && location.state.batchId) {
      const b = getBatchById(location.state.batchId);
      if (b) { setEditBatchId(b.id); setInstruction(b.instruction); setPayments(b.payments); }
    }
  }, [location.state]);

  const onInstruction = (e) => setInstruction(p => ({...p, [e.target.name]: e.target.value}));
  const onPayment = (i, e) => setPayments(prev => { const n=[...prev]; n[i][e.target.name]=e.target.value; return n; });
  const addRow = () => setPayments(prev => [...prev, emptyRow()]);
  const removeRow = (i) => setPayments(prev => prev.filter((_,idx)=>idx!==i));

  const persist = (status) => {
    const batch = { id: editBatchId || Date.now(), instruction, payments, status, createdAt: editBatchId? undefined : new Date().toISOString(), updatedAt:new Date().toISOString() };
    upsertBatch(batch);
  };
  const saveDraft = () => { persist('Draft'); navigate('/manage-payroll'); }
  const submit = (e) => { e.preventDefault(); persist('Submitted'); navigate('/manage-payroll'); }

  // Excel upload hook (minimal)
  const handleExcel = () => document.getElementById('excel-input').click();
  const onExcel = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        // Expect CSV with: payeeDetails,payeeName,accountNumber,amount
        const lines = evt.target.result.split(/\r?\n/).filter(Boolean);
        const rows = lines.slice(1).map(line => {
          const [payeeDetails,payeeName,accountNumber,amount] = line.split(',');
          return { payeeDetails, payeeName, accountNumber, amount, reference:`REF-${Date.now()}-${Math.random().toString(36).slice(2,6)}` };
        });
        if (rows.length) setPayments(rows);
      } catch(err) { alert('Failed to parse file. Use CSV format.'); }
    };
    reader.readAsText(file);
  };

  return (
    <div className="container my-2">
      <div className="card">
        <div className="d-flex justify-content-between align-items-center mb-2">
          <h2>{editBatchId ? 'Edit Payroll Batch' : 'Create Payroll Payments'}</h2>
          <BackToDashboard />
        </div>

        <form onSubmit={submit}>
          <h4 className="mb-2">Instruction Details</h4>
          <div className="grid" style={{gridTemplateColumns:'repeat(3, minmax(0,1fr))'}}>
            <div>
              <label className="form-label">Currency *</label>
              <select className="form-select form-select-sm" name="paymentCurrency" value={instruction.paymentCurrency} onChange={onInstruction} required>
                <option value="">Select</option>
                {currencies.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div>
              <label className="form-label">Debit Account *</label>
              <select className="form-select form-select-sm" name="debitAccount" value={instruction.debitAccount} onChange={onInstruction} required>
                <option value="">Select</option>
                {accounts.map(a => <option key={a.id} value={a.number}>{a.number} — {a.name}</option>)}
              </select>
            </div>
            <div>
              <label className="form-label">Date *</label>
              <input type="date" className="form-control form-control-sm" name="date" value={instruction.date} onChange={onInstruction} required />
            </div>
          </div>

          <div className="d-flex justify-content-between align-items-center mt-3">
            <h4 className="mb-0">Payment Details</h4>
            <div className="d-flex gap-2">
              <input id="excel-input" type="file" accept=".csv" style={{display:'none'}} onChange={onExcel} />
              <button className="btn btn-outline-primary" type="button" onClick={handleExcel}>
                <i className="bi bi-file-earmark-spreadsheet me-1"></i> Upload CSV
              </button>
              <button type="button" className="btn btn-outline-primary" onClick={addRow}>+ Add Row</button>
            </div>
          </div>

          <div className="table-responsive" style={{marginTop:10}}>
            <table className="table align-middle text-center">
              <thead>
                <tr>
                  <th>Reference</th>
                  <th>Payee Role *</th>
                  <th>Payee Name *</th>
                  <th>Account Number *</th>
                  <th>Amount *</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {payments.map((p,i)=>(
                  <tr key={i}>
                    <td><input className="form-control form-control-sm" value={p.reference} readOnly/></td>
                    <td>
                      <select className="form-select form-select-sm" name="payeeDetails" value={p.payeeDetails} onChange={(e)=>onPayment(i,e)} required>
                        <option value="">Select</option>
                        <option value="Permanent employees">Permanent Employee</option>
                        <option value="Temporary employees">Temporary Employee</option>
                        <option value="Consultant">Consultant</option>
                        <option value="Apprentices/Interns/Trainees">Apprentices/Interns/Trainees</option>
                        <option value="Foreign Employees">Foreign Employees</option>
                      </select>
                    </td>
                    <td><input className="form-control form-control-sm" name="payeeName" value={p.payeeName} onChange={(e)=>onPayment(i,e)} required/></td>
                    <td><input className="form-control form-control-sm" name="accountNumber" value={p.accountNumber} onChange={(e)=>onPayment(i,e)} required/></td>
                    <td><input className="form-control form-control-sm" type="number" min="1" name="amount" value={p.amount} onChange={(e)=>onPayment(i,e)} required/></td>
                    <td><button type="button" className="btn btn-outline-primary" onClick={()=>removeRow(i)}>Remove</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="d-flex justify-content-between align-items-center mt-2">
            <BackToDashboard />
            <div className="d-flex gap-2">
              <button type="button" className="btn btn-outline-primary" onClick={saveDraft}>Save Draft</button>
              <button type="submit" className="btn btn-primary">Submit</button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
