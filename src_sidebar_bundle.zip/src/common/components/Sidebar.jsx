import React from 'react';
import { NavLink } from 'react-router-dom';

const navItems = [
  { to: '/dashboard', icon: 'bi-house-door', label: 'Dashboard' },
  { to: '/payroll', icon: 'bi-cash-coin', label: 'Payroll' },
  { to: '/manage-payroll', icon: 'bi-list-check', label: 'Manage' },
  { to: '/approvals', icon: 'bi-shield-check', label: 'Approvals' },
  { to: '/txns', icon: 'bi-clock-history', label: 'Transactions' },
  { to: '/balances', icon: 'bi-wallet2', label: 'Balance' },
  { to: '/print', icon: 'bi-printer', label: 'Print' },
];

export default function Sidebar() {
  const allowed = JSON.parse(localStorage.getItem('allowedPages') || '[]');
  const allowedPaths = new Set(allowed.map(p => p.path));

  return (
    <aside className="sidebar">
      <nav>
        {navItems
          .filter(item => item.to === '/dashboard' || allowedPaths.has(item.to))
          .map(item => (
          <NavLink key={item.to} to={item.to} className={({isActive}) => 'side-link' + (isActive ? ' active' : '')}>
            <i className={`bi ${item.icon}`} />
            <span>{item.label}</span>
          </NavLink>
        ))}
      </nav>
    </aside>
  );
}
