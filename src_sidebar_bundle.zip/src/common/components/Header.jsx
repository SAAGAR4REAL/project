import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import logo from '../../assets/sc-logo.png';
import { subscribeToPayrollEvents } from '../storage/payrollStore';

export default function Header({ title, currentUser }) {
  const navigate = useNavigate();
  const [dark, setDark] = useState(localStorage.getItem('theme') === 'dark');
  const [notifications, setNotifications] = useState([]);
  const [unread, setUnread] = useState(0);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', dark ? 'dark' : 'light');
    localStorage.setItem('theme', dark ? 'dark' : 'light');
  }, [dark]);

  useEffect(() => {
    const unsub = subscribeToPayrollEvents((event) => {
      let msg = null, type='info';
      if (event.type === 'statusChanged') {
        if (event.status === 'Submitted') { msg = `Batch #${event.batch.id} submitted`; type='warning'; }
        if (event.status === 'Approved')  { msg = `Batch #${event.batch.id} approved`; type='success'; }
        if (event.status === 'Rejected')  { msg = `Batch #${event.batch.id} rejected`; type='danger'; }
      } else if (event.type === 'created') { msg = `Batch #${event.batch.id} created`; type='info'; }
      else if (event.type === 'deleted') { msg = `Batch #${event.batchId} deleted`; type='danger'; }
      if (msg) {
        setNotifications(prev => [{ id: Date.now(), msg, type, time: new Date().toLocaleTimeString(), read:false }, ...prev]);
        setUnread(u => u + 1);
      }
    });
    return () => unsub();
  }, []);

  const logout = () => {
    const last = new Date().toISOString();
    localStorage.setItem('lastLogout', last);
    localStorage.removeItem('allowedPages');
    navigate('/login');
  };

  const gotoHome = () => navigate('/dashboard');

  const toggleDrop = () => {
    setOpen(o => !o);
    if (!open) {
      setUnread(0);
      setNotifications(prev => prev.map(n => ({...n, read:true})));
    }
  }

  return (
    <header className="topbar brand-gradient">
      <div className="topbar-left" onClick={gotoHome} style={{cursor:'pointer'}}>
        <img src={logo} alt="SCB" className="header-logo"/>
        <div className="titles">
          <div className="app-title">Payment Initiations</div>
          {title && <div className="page-title">{title}</div>}
        </div>
      </div>
      <div className="topbar-right">
        <button className="icon-btn" onClick={() => setDark(d => !d)} title="Toggle theme">
          <i className={dark ? 'bi bi-brightness-high' : 'bi bi-moon'}></i>
        </button>

        <div className="notify">
          <button className="icon-btn" onClick={toggleDrop} title="Notifications">
            <i className="bi bi-bell"></i>
            {unread > 0 && <span className="badge">{unread}</span>}
          </button>
          {open && (
            <div className="notify-dropdown">
              <div className="notify-header">Notifications</div>
              {notifications.length === 0 ? (
                <div className="notify-empty">No notifications</div>
              ) : (
                notifications.slice(0,8).map(n => (
                  <div key={n.id} className={`notify-item ${n.type}`}>
                    <div className="msg">{n.msg}</div>
                    <div className="time">{n.time}</div>
                  </div>
                ))
              )}
            </div>
          )}
        </div>

        <div className="user-chip">
          <i className="bi bi-person-circle me-1"></i>
          {currentUser || 'GUEST'}
        </div>

        <button className="btn btn-outline-light btn-sm" onClick={logout}>
          Logout
        </button>
      </div>
    </header>
  );
}
