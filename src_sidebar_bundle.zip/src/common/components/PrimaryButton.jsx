import React from 'react';
export default function PrimaryButton({ children, ...rest }) {
  return <button className="btn btn-primary" {...rest}>{children}</button>;
}
