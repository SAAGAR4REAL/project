import React from 'react';

export default function Footer({ currentUser }) {
  const lastLogin = localStorage.getItem('lastLogin');
  const lastLogout = localStorage.getItem('lastLogout');

  return (
    <footer className="footer-bar">
      <div>© 2025 Standard Chartered. All rights reserved.</div>
      <div className="foot-right">
        <span>Current User: <strong>{currentUser || 'GUEST'}</strong></span>
        {lastLogin && <span>Last Login: {new Date(lastLogin).toLocaleString()}</span>}
        {lastLogout && <span>Last Logout: {new Date(lastLogout).toLocaleString()}</span>}
      </div>
    </footer>
  );
}
