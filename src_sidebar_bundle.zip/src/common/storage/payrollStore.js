const KEY = 'payroll_batches_v2';

export const getAllBatches = () => {
  try {
    return JSON.parse(localStorage.getItem(KEY)) || [];
  } catch {
    return [];
  }
};

export const saveAllBatches = (arr) => {
  localStorage.setItem(KEY, JSON.stringify(arr));
};

export const getBatchById = (id) => getAllBatches().find(b => b.id === id);

let listeners = [];
export const subscribeToPayrollEvents = (cb) => {
  listeners.push(cb);
  return () => { listeners = listeners.filter(fn => fn !== cb); };
};
const notify = (event) => listeners.forEach(cb => cb(event));

export const upsertBatch = (batch) => {
  const data = getAllBatches();
  const i = data.findIndex(b => b.id === batch.id);
  if (i >= 0) data[i] = batch; else data.push(batch);
  saveAllBatches(data);
  notify({ type: i>=0 ? 'updated' : 'created', batch });
};

export const setStatus = (batchId, status, meta={}) => {
  const data = getAllBatches();
  const i = data.findIndex(b => b.id === batchId);
  if (i >= 0) {
    data[i] = { ...data[i], status, ...meta, updatedAt: new Date().toISOString() };
    saveAllBatches(data);
    notify({ type: 'statusChanged', status, batch: data[i] });
  }
};

export const deleteBatch = (batchId) => {
  const data = getAllBatches().filter(b => b.id !== batchId);
  saveAllBatches(data);
  notify({ type: 'deleted', batchId });
};

export const downloadText = (filename, content) => {
  const blob = new Blob([content], { type: 'text/plain' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
};
